# VideoStreamingFlask
Streaming video with the help of Flask and Opencv
