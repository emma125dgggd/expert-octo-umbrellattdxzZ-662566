import cv2
import pandas as pd
import datetime as dt
face=cv2.CascadeClassifier("haarcascade_frontalface_alt2.xml")
ds_factor=0.6

tm=[]
num=[]

stat = 0

class VideoCamera(object):
    def __init__(self):
        #send the video file to TrestleApp folder
        self.video = cv2.VideoCapture("Enter Name of Video")
    
    def __del__(self):
        self.video.release()
    
    def get_frame(self):

        check, img = self.video.read()
        i = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face.detectMultiScale(i, scaleFactor=1.1, minNeighbors=5)
        print(img)
        print(type(faces))
        if len(faces) == 0:
            print("No Faces")
        else:
            print(faces)
            print(faces.shape)
            print("Number of Faces detected: " + str(faces.shape[0]))
            for x, y, w, h in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 3)
                stat = 1
                stat_list = [None]
                stat_list.append(stat)
                stat_list = stat_list[-2:]
                if stat_list[-1] == 1:
                    tm.append(dt.datetime.now())
                    num.append(faces.shape[0])
            cv2.rectangle(img, ((0, img.shape[0] - 25)), (270, img.shape[0]), (255, 255, 255, 1))
            cv2.putText(img, "Number of faces detected: " + str(faces.shape[0]), (0, img.shape[0] - 10),
                        cv2.FONT_HERSHEY_TRIPLEX, 0.5, (0, 0, 0), 1)
            print(tm)
            df = pd.DataFrame(columns=["Time", "Number of People"])
            for i in range(0, len(tm), 2):

                df = df.append({"Time": tm[i], "Number of People": num[i]}, ignore_index=True)
            df.to_csv("records/t.csv")
            df.to_html("records/v.html")
        ret, jpeg = cv2.imencode('.jpg', img)
        return jpeg.tobytes()

